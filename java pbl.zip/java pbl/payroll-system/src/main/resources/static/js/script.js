/**
 * Modern JavaScript for Payroll System
 */

document.addEventListener('DOMContentLoaded', function() {
    // Initialize tooltips
    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    var tooltipList = tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });

    // Initialize popovers
    var popoverTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="popover"]'));
    var popoverList = popoverTriggerList.map(function (popoverTriggerEl) {
        return new bootstrap.Popover(popoverTriggerEl);
    });

    // Auto-hide alerts after 5 seconds
    setTimeout(function() {
        var alerts = document.querySelectorAll('.alert');
        alerts.forEach(function(alert) {
            var bsAlert = new bootstrap.Alert(alert);
            bsAlert.close();
        });
    }, 5000);

    // Add tooltip to all action buttons
    document.querySelectorAll('.btn-group .btn').forEach(function(btn) {
        if (!btn.getAttribute('title')) {
            btn.setAttribute('data-bs-toggle', 'tooltip');
            btn.setAttribute('data-bs-placement', 'top');
            
            if (btn.classList.contains('btn-info')) {
                btn.setAttribute('title', 'View Details');
            } else if (btn.classList.contains('btn-warning')) {
                btn.setAttribute('title', 'Edit');
            } else if (btn.classList.contains('btn-danger')) {
                btn.setAttribute('title', 'Delete');
            } else if (btn.classList.contains('btn-success')) {
                btn.setAttribute('title', 'View Salaries');
            }
        }
    });

    // Reinitialize tooltips
    var tooltipTriggerList = [].slice.call(document.querySelectorAll('[data-bs-toggle="tooltip"]'));
    tooltipTriggerList.map(function (tooltipTriggerEl) {
        return new bootstrap.Tooltip(tooltipTriggerEl);
    });

    // Employee form - calculate net salary
    var basicSalaryInput = document.getElementById('basicSalary');
    var taxPercentageInput = document.getElementById('taxPercentage');
    var allowancesInput = document.getElementById('allowances');
    var deductionsInput = document.getElementById('deductions');
    var netSalaryDisplay = document.getElementById('netSalaryDisplay');

    function calculateNetSalary() {
        if (!basicSalaryInput) return;
        
        var basicSalary = parseFloat(basicSalaryInput.value) || 0;
        var taxPercentage = parseFloat(taxPercentageInput.value) || 0;
        var allowances = parseFloat(allowancesInput.value) || 0;
        var deductions = parseFloat(deductionsInput.value) || 0;
        
        var taxAmount = basicSalary * (taxPercentage / 100);
        var netSalary = basicSalary + allowances - deductions - taxAmount;
        
        if (netSalaryDisplay) {
            netSalaryDisplay.textContent = '$' + netSalary.toFixed(2);
            
            // Add animation effect
            netSalaryDisplay.classList.add('highlight');
            setTimeout(function() {
                netSalaryDisplay.classList.remove('highlight');
            }, 500);
        }
    }

    // Add event listeners for salary calculation if elements exist
    if (basicSalaryInput) {
        basicSalaryInput.addEventListener('input', calculateNetSalary);
    }
    if (taxPercentageInput) {
        taxPercentageInput.addEventListener('input', calculateNetSalary);
    }
    if (allowancesInput) {
        allowancesInput.addEventListener('input', calculateNetSalary);
    }
    if (deductionsInput) {
        deductionsInput.addEventListener('input', calculateNetSalary);
    }

    // Salary form - populate employee data
    var employeeSelect = document.getElementById('employee');
    if (employeeSelect) {
        employeeSelect.addEventListener('change', function() {
            if (employeeSelect.value) {
                console.log('Employee selected: ' + employeeSelect.value);
                
                // Add visual feedback
                employeeSelect.classList.add('is-valid');
                
                // In a real application, you would fetch employee data and populate fields
                // For now, just show a notification
                showNotification('Employee selected', 'success');
            }
        });
    }

    // Date range validation for salary search
    var startDateInput = document.getElementById('startDate');
    var endDateInput = document.getElementById('endDate');
    
    if (startDateInput && endDateInput) {
        endDateInput.addEventListener('change', function() {
            if (startDateInput.value && endDateInput.value) {
                var startDate = new Date(startDateInput.value);
                var endDate = new Date(endDateInput.value);
                
                if (endDate < startDate) {
                    showNotification('End date cannot be before start date', 'danger');
                    endDateInput.value = '';
                    endDateInput.classList.add('is-invalid');
                } else {
                    startDateInput.classList.add('is-valid');
                    endDateInput.classList.add('is-valid');
                }
            }
        });
    }
    
    // Add active class to current nav item
    var currentPath = window.location.pathname;
    document.querySelectorAll('.navbar-nav .nav-link').forEach(function(link) {
        var href = link.getAttribute('href');
        if (href === currentPath || (href !== '/' && currentPath.startsWith(href))) {
            link.classList.add('active');
            link.setAttribute('aria-current', 'page');
        }
    });
    
    // Add animation to dashboard cards
    var cards = document.querySelectorAll('.card');
    cards.forEach(function(card, index) {
        card.style.animationDelay = (index * 0.1) + 's';
    });
    
    // Function to show notifications
    function showNotification(message, type) {
        var notificationContainer = document.getElementById('notification-container');
        
        if (!notificationContainer) {
            notificationContainer = document.createElement('div');
            notificationContainer.id = 'notification-container';
            notificationContainer.style.position = 'fixed';
            notificationContainer.style.top = '20px';
            notificationContainer.style.right = '20px';
            notificationContainer.style.zIndex = '9999';
            document.body.appendChild(notificationContainer);
        }
        
        var notification = document.createElement('div');
        notification.className = 'toast align-items-center text-white bg-' + type;
        notification.setAttribute('role', 'alert');
        notification.setAttribute('aria-live', 'assertive');
        notification.setAttribute('aria-atomic', 'true');
        
        notification.innerHTML = `
            <div class="d-flex">
                <div class="toast-body">
                    ${message}
                </div>
                <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast" aria-label="Close"></button>
            </div>
        `;
        
        notificationContainer.appendChild(notification);
        
        var toast = new bootstrap.Toast(notification, {
            autohide: true,
            delay: 3000
        });
        
        toast.show();
        
        notification.addEventListener('hidden.bs.toast', function() {
            notification.remove();
        });
    }
    
    // Add CSS for highlight animation
    var style = document.createElement('style');
    style.textContent = `
        @keyframes highlight {
            0% { color: inherit; }
            50% { color: #10b981; }
            100% { color: inherit; }
        }
        .highlight {
            animation: highlight 0.5s ease;
        }
        
        .navbar .nav-link.active {
            background-color: rgba(255, 255, 255, 0.2);
            font-weight: 600;
        }
        
        #notification-container {
            display: flex;
            flex-direction: column;
            gap: 10px;
        }
        
        .toast {
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.15);
            border-radius: 8px;
            overflow: hidden;
            transition: all 0.3s ease;
        }
    `;
    document.head.appendChild(style);
}); 