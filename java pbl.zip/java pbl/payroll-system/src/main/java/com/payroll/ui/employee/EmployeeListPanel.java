package com.payroll.ui.employee;

import com.payroll.model.Employee;
import com.payroll.repository.EmployeeRepository;
import com.payroll.ui.MainFrame;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class EmployeeListPanel extends JPanel {

    private final EmployeeRepository employeeRepository;
    private final MainFrame mainFrame;
    
    private JTable employeeTable;
    private DefaultTableModel tableModel;
    private JButton addButton;
    private JButton editButton;
    private JButton deleteButton;
    private JTextField searchField;
    
    public EmployeeListPanel(EmployeeRepository employeeRepository, MainFrame mainFrame) {
        this.employeeRepository = employeeRepository;
        this.mainFrame = mainFrame;
        
        setLayout(new BorderLayout(10, 10));
        setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));
        
        // Create header panel
        JPanel headerPanel = createHeaderPanel();
        add(headerPanel, BorderLayout.NORTH);
        
        // Create table panel
        JPanel tablePanel = createTablePanel();
        add(tablePanel, BorderLayout.CENTER);
        
        // Create button panel
        JPanel buttonPanel = createButtonPanel();
        add(buttonPanel, BorderLayout.SOUTH);
        
        // Load initial data
        refreshEmployeeList();
    }
    
    private JPanel createHeaderPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBorder(BorderFactory.createEmptyBorder(0, 0, 15, 0));
        
        JLabel titleLabel = new JLabel("Employee Management");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 20));
        panel.add(titleLabel, BorderLayout.WEST);
        
        JPanel searchPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        
        searchField = new JTextField(20);
        JButton searchButton = new JButton("Search");
        
        searchPanel.add(new JLabel("Search: "));
        searchPanel.add(searchField);
        searchPanel.add(searchButton);
        
        panel.add(searchPanel, BorderLayout.EAST);
        
        return panel;
    }
    
    private JPanel createTablePanel() {
        JPanel panel = new JPanel(new BorderLayout());
        
        // Create table model with column names
        String[] columnNames = {"ID", "Name", "Position", "Department", "Email", "Phone", "Basic Salary"};
        tableModel = new DefaultTableModel(columnNames, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false; // Make table cells non-editable
            }
        };
        
        // Create table with the model
        employeeTable = new JTable(tableModel);
        employeeTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        employeeTable.setRowHeight(30);
        
        // Add table to scroll pane
        JScrollPane scrollPane = new JScrollPane(employeeTable);
        panel.add(scrollPane, BorderLayout.CENTER);
        
        return panel;
    }
    
    private JPanel createButtonPanel() {
        JPanel panel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        panel.setBorder(BorderFactory.createEmptyBorder(15, 0, 0, 0));
        
        addButton = new JButton("Add Employee");
        editButton = new JButton("Edit");
        deleteButton = new JButton("Delete");
        
        // Initially disable edit and delete buttons
        editButton.setEnabled(false);
        deleteButton.setEnabled(false);
        
        // Add action listeners
        addButton.addActionListener(e -> showAddEmployeeForm());
        editButton.addActionListener(e -> showEditEmployeeForm());
        deleteButton.addActionListener(e -> deleteSelectedEmployee());
        
        // Add selection listener to enable/disable buttons
        employeeTable.getSelectionModel().addListSelectionListener(e -> {
            boolean rowSelected = employeeTable.getSelectedRow() != -1;
            editButton.setEnabled(rowSelected);
            deleteButton.setEnabled(rowSelected);
        });
        
        panel.add(addButton);
        panel.add(editButton);
        panel.add(deleteButton);
        
        return panel;
    }
    
    private void showAddEmployeeForm() {
        mainFrame.showEmployeeForm(null); // Pass null for new employee
    }
    
    private void showEditEmployeeForm() {
        int selectedRow = employeeTable.getSelectedRow();
        if (selectedRow != -1) {
            Long employeeId = (Long) tableModel.getValueAt(selectedRow, 0);
            Employee employee = employeeRepository.findById(employeeId).orElse(null);
            if (employee != null) {
                mainFrame.showEmployeeForm(employee);
            }
        }
    }
    
    private void deleteSelectedEmployee() {
        int selectedRow = employeeTable.getSelectedRow();
        if (selectedRow != -1) {
            Long employeeId = (Long) tableModel.getValueAt(selectedRow, 0);
            
            int confirm = JOptionPane.showConfirmDialog(
                    this,
                    "Are you sure you want to delete this employee?",
                    "Confirm Delete",
                    JOptionPane.YES_NO_OPTION
            );
            
            if (confirm == JOptionPane.YES_OPTION) {
                employeeRepository.deleteById(employeeId);
                refreshEmployeeList();
                mainFrame.refreshAllData();
            }
        }
    }
    
    public void refreshEmployeeList() {
        // Clear existing data
        tableModel.setRowCount(0);
        
        // Get all employees
        List<Employee> employees = employeeRepository.findAll();
        
        // Add employee data to table model
        for (Employee employee : employees) {
            Object[] rowData = {
                    employee.getId(),
                    employee.getFirstName() + " " + employee.getLastName(),
                    employee.getPosition(),
                    employee.getDepartment(),
                    employee.getEmail(),
                    employee.getPhone(),
                    "$" + employee.getBasicSalary()
            };
            tableModel.addRow(rowData);
        }
    }
} 