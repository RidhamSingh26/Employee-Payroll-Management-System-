package com.payroll.service;

import com.payroll.model.Employee;
import com.payroll.model.Salary;
import com.payroll.repository.EmployeeRepository;
import com.payroll.repository.SalaryRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.persistence.EntityNotFoundException;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.List;

@Service
public class SalaryService {

    private final SalaryRepository salaryRepository;
    private final EmployeeRepository employeeRepository;

    @Autowired
    public SalaryService(SalaryRepository salaryRepository, EmployeeRepository employeeRepository) {
        this.salaryRepository = salaryRepository;
        this.employeeRepository = employeeRepository;
    }

    public List<Salary> getAllSalaries() {
        return salaryRepository.findAll();
    }

    public Salary getSalaryById(Long id) {
        return salaryRepository.findById(id)
                .orElseThrow(() -> new EntityNotFoundException("Salary record not found with ID: " + id));
    }

    public List<Salary> getSalariesByEmployee(Long employeeId) {
        return salaryRepository.findByEmployeeId(employeeId);
    }

    public List<Salary> getSalariesByDateRange(LocalDate startDate, LocalDate endDate) {
        return salaryRepository.findByPaymentDateBetween(startDate, endDate);
    }

    public List<Salary> getSalariesByPaymentPeriod(String paymentPeriod) {
        return salaryRepository.findByPaymentPeriod(paymentPeriod);
    }

    public List<Salary> getSalariesByPaymentStatus(String paymentStatus) {
        return salaryRepository.findByPaymentStatus(paymentStatus);
    }

    public Salary createSalary(Salary salary) {
        Employee employee = employeeRepository.findById(salary.getEmployee().getId())
                .orElseThrow(() -> new EntityNotFoundException("Employee not found with ID: " + salary.getEmployee().getId()));
        
        salary.setEmployee(employee);
        
        // Set basic salary from employee if not provided
        if (salary.getBasicSalary() == null) {
            salary.setBasicSalary(employee.getBasicSalary());
        }
        
        // Calculate tax amount if not provided
        if (salary.getTaxAmount() == null && employee.getTaxPercentage() != null) {
            BigDecimal taxAmount = salary.getBasicSalary().multiply(employee.getTaxPercentage().divide(new BigDecimal("100"), 10, BigDecimal.ROUND_HALF_UP));
            salary.setTaxAmount(taxAmount);
        }
        
        // Set payment date to today if not provided
        if (salary.getPaymentDate() == null) {
            salary.setPaymentDate(LocalDate.now());
        }
        
        // Set default payment status if not provided
        if (salary.getPaymentStatus() == null) {
            salary.setPaymentStatus("PENDING");
        }
        
        // Calculate net salary
        salary.calculateNetSalary();
        
        return salaryRepository.save(salary);
    }

    public Salary updateSalary(Long id, Salary salaryDetails) {
        Salary salary = getSalaryById(id);
        
        salary.setPaymentDate(salaryDetails.getPaymentDate());
        salary.setPaymentPeriod(salaryDetails.getPaymentPeriod());
        salary.setBasicSalary(salaryDetails.getBasicSalary());
        salary.setOvertimeHours(salaryDetails.getOvertimeHours());
        salary.setOvertimeRate(salaryDetails.getOvertimeRate());
        salary.setAllowances(salaryDetails.getAllowances());
        salary.setDeductions(salaryDetails.getDeductions());
        salary.setTaxAmount(salaryDetails.getTaxAmount());
        salary.setPaymentStatus(salaryDetails.getPaymentStatus());
        salary.setPaymentMethod(salaryDetails.getPaymentMethod());
        salary.setRemarks(salaryDetails.getRemarks());
        
        // Recalculate net salary
        salary.calculateNetSalary();
        
        return salaryRepository.save(salary);
    }

    public void deleteSalary(Long id) {
        Salary salary = getSalaryById(id);
        salaryRepository.delete(salary);
    }
} 