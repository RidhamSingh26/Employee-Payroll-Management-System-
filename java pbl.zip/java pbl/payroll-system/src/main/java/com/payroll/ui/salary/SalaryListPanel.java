package com.payroll.ui.salary;

import com.payroll.model.Salary;
import com.payroll.repository.EmployeeRepository;
import com.payroll.repository.SalaryRepository;
import com.payroll.ui.MainFrame;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.List;

public class SalaryListPanel extends JPanel {

    private final SalaryRepository salaryRepository;
    private final EmployeeRepository employeeRepository;
    private final MainFrame mainFrame;
    
    private JTable salaryTable;
    private DefaultTableModel tableModel;
    private JButton addButton;
    private JButton editButton;
    private JButton deleteButton;
    private JTextField searchField;
    
    public SalaryListPanel(SalaryRepository salaryRepository, EmployeeRepository employeeRepository, MainFrame mainFrame) {
        this.salaryRepository = salaryRepository;
        this.employeeRepository = employeeRepository;
        this.mainFrame = mainFrame;
        
        setLayout(new BorderLayout(10, 10));
        setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));
        
        // Create header panel
        JPanel headerPanel = createHeaderPanel();
        add(headerPanel, BorderLayout.NORTH);
        
        // Create table panel
        JPanel tablePanel = createTablePanel();
        add(tablePanel, BorderLayout.CENTER);
        
        // Create button panel
        JPanel buttonPanel = createButtonPanel();
        add(buttonPanel, BorderLayout.SOUTH);
        
        // Load initial data
        refreshSalaryList();
    }
    
    private JPanel createHeaderPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBorder(BorderFactory.createEmptyBorder(0, 0, 15, 0));
        
        JLabel titleLabel = new JLabel("Salary Management");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 20));
        panel.add(titleLabel, BorderLayout.WEST);
        
        JPanel searchPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        
        searchField = new JTextField(20);
        JButton searchButton = new JButton("Search");
        
        searchPanel.add(new JLabel("Search: "));
        searchPanel.add(searchField);
        searchPanel.add(searchButton);
        
        panel.add(searchPanel, BorderLayout.EAST);
        
        return panel;
    }
    
    private JPanel createTablePanel() {
        JPanel panel = new JPanel(new BorderLayout());
        
        // Create table model with column names
        String[] columnNames = {"ID", "Employee", "Payment Date", "Period", "Amount", "Status"};
        tableModel = new DefaultTableModel(columnNames, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false; // Make table cells non-editable
            }
        };
        
        // Create table with the model
        salaryTable = new JTable(tableModel);
        salaryTable.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        salaryTable.setRowHeight(30);
        
        // Add table to scroll pane
        JScrollPane scrollPane = new JScrollPane(salaryTable);
        panel.add(scrollPane, BorderLayout.CENTER);
        
        return panel;
    }
    
    private JPanel createButtonPanel() {
        JPanel panel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        panel.setBorder(BorderFactory.createEmptyBorder(15, 0, 0, 0));
        
        addButton = new JButton("Add Salary Record");
        editButton = new JButton("Edit");
        deleteButton = new JButton("Delete");
        
        // Initially disable edit and delete buttons
        editButton.setEnabled(false);
        deleteButton.setEnabled(false);
        
        // Add action listeners
        addButton.addActionListener(e -> showAddSalaryForm());
        editButton.addActionListener(e -> showEditSalaryForm());
        deleteButton.addActionListener(e -> deleteSelectedSalary());
        
        // Add selection listener to enable/disable buttons
        salaryTable.getSelectionModel().addListSelectionListener(e -> {
            boolean rowSelected = salaryTable.getSelectedRow() != -1;
            editButton.setEnabled(rowSelected);
            deleteButton.setEnabled(rowSelected);
        });
        
        panel.add(addButton);
        panel.add(editButton);
        panel.add(deleteButton);
        
        return panel;
    }
    
    private void showAddSalaryForm() {
        mainFrame.showSalaryForm(null); // Pass null for new salary record
    }
    
    private void showEditSalaryForm() {
        int selectedRow = salaryTable.getSelectedRow();
        if (selectedRow != -1) {
            Long salaryId = (Long) tableModel.getValueAt(selectedRow, 0);
            Salary salary = salaryRepository.findById(salaryId).orElse(null);
            if (salary != null) {
                mainFrame.showSalaryForm(salary);
            }
        }
    }
    
    private void deleteSelectedSalary() {
        int selectedRow = salaryTable.getSelectedRow();
        if (selectedRow != -1) {
            Long salaryId = (Long) tableModel.getValueAt(selectedRow, 0);
            
            int confirm = JOptionPane.showConfirmDialog(
                    this,
                    "Are you sure you want to delete this salary record?",
                    "Confirm Delete",
                    JOptionPane.YES_NO_OPTION
            );
            
            if (confirm == JOptionPane.YES_OPTION) {
                salaryRepository.deleteById(salaryId);
                refreshSalaryList();
                mainFrame.refreshAllData();
            }
        }
    }
    
    public void refreshSalaryList() {
        // Clear existing data
        tableModel.setRowCount(0);
        
        // Get all salaries
        List<Salary> salaries = salaryRepository.findAll();
        
        // Add salary data to table model
        for (Salary salary : salaries) {
            Object[] rowData = {
                    salary.getId(),
                    salary.getEmployee().getFirstName() + " " + salary.getEmployee().getLastName(),
                    salary.getPaymentDate(),
                    salary.getPaymentPeriod(),
                    "$" + salary.getNetSalary(),
                    salary.getPaymentStatus()
            };
            tableModel.addRow(rowData);
        }
    }
} 