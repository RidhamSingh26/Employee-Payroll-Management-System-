package com.payroll.ui.salary;

import com.payroll.model.Employee;
import com.payroll.model.Salary;
import com.payroll.repository.EmployeeRepository;
import com.payroll.repository.SalaryRepository;

import javax.swing.*;
import java.awt.*;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class SalaryFormPanel extends JPanel {

    private final SalaryRepository salaryRepository;
    private final EmployeeRepository employeeRepository;
    private final JDialog parentDialog;
    private final Salary salaryToEdit;
    
    private JComboBox<String> employeeComboBox;
    private Map<String, Long> employeeNameToIdMap;
    private JTextField paymentDateField;
    private JTextField paymentPeriodField;
    private JTextField basicSalaryField;
    private JTextField overtimeHoursField;
    private JTextField overtimeRateField;
    private JTextField allowancesField;
    private JTextField deductionsField;
    private JTextField taxAmountField;
    private JTextField netSalaryField;
    private JComboBox<String> paymentStatusComboBox;
    private JTextField paymentMethodField;
    private JTextArea remarksArea;
    
    private JButton calculateButton;
    private JButton saveButton;
    private JButton cancelButton;
    
    public SalaryFormPanel(SalaryRepository salaryRepository, EmployeeRepository employeeRepository, JDialog parentDialog, Salary salaryToEdit) {
        this.salaryRepository = salaryRepository;
        this.employeeRepository = employeeRepository;
        this.parentDialog = parentDialog;
        this.salaryToEdit = salaryToEdit;
        
        setLayout(new BorderLayout(10, 10));
        setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));
        
        // Create form panel
        JPanel formPanel = createFormPanel();
        
        // Add scroll pane for the form
        JScrollPane scrollPane = new JScrollPane(formPanel);
        scrollPane.setBorder(null);
        scrollPane.getVerticalScrollBar().setUnitIncrement(16);
        add(scrollPane, BorderLayout.CENTER);
        
        // Create button panel
        JPanel buttonPanel = createButtonPanel();
        add(buttonPanel, BorderLayout.SOUTH);
        
        // Load salary data if editing
        if (salaryToEdit != null) {
            loadSalaryData();
        } else {
            // Set default values for new salary
            LocalDate now = LocalDate.now();
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
            paymentDateField.setText(now.format(formatter));
            
            // Set default payment period (e.g., "June 2023")
            paymentPeriodField.setText(now.getMonth().toString() + " " + now.getYear());
            
            overtimeHoursField.setText("0");
            overtimeRateField.setText("0.0");
            allowancesField.setText("0.0");
            deductionsField.setText("0.0");
            taxAmountField.setText("0.0");
            netSalaryField.setText("0.0");
            paymentStatusComboBox.setSelectedItem("PENDING");
            paymentMethodField.setText("Bank Transfer");
        }
    }
    
    private JPanel createFormPanel() {
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBorder(BorderFactory.createEmptyBorder(0, 0, 10, 0));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(5, 5, 5, 5);
        
        // Create form fields
        // Populate employee combo box
        employeeNameToIdMap = new HashMap<>();
        List<Employee> employees = employeeRepository.findAll();
        String[] employeeNames = employees.stream()
                .map(e -> e.getFirstName() + " " + e.getLastName())
                .toArray(String[]::new);
        
        // Create employee ID to name mapping
        for (Employee employee : employees) {
            String fullName = employee.getFirstName() + " " + employee.getLastName();
            employeeNameToIdMap.put(fullName, employee.getId());
        }
        
        employeeComboBox = new JComboBox<>(employeeNames);
        paymentDateField = new JTextField(20);
        paymentPeriodField = new JTextField(20);
        basicSalaryField = new JTextField(20);
        overtimeHoursField = new JTextField(20);
        overtimeRateField = new JTextField(20);
        allowancesField = new JTextField(20);
        deductionsField = new JTextField(20);
        taxAmountField = new JTextField(20);
        netSalaryField = new JTextField(20);
        
        String[] paymentStatuses = {"PAID", "PENDING", "FAILED"};
        paymentStatusComboBox = new JComboBox<>(paymentStatuses);
        
        paymentMethodField = new JTextField(20);
        remarksArea = new JTextArea(4, 20);
        remarksArea.setLineWrap(true);
        remarksArea.setWrapStyleWord(true);
        
        // Add employee selection listener to update basic salary
        employeeComboBox.addActionListener(e -> {
            String selectedEmployeeName = (String) employeeComboBox.getSelectedItem();
            if (selectedEmployeeName != null && !selectedEmployeeName.isEmpty()) {
                Long employeeId = employeeNameToIdMap.get(selectedEmployeeName);
                if (employeeId != null) {
                    Employee employee = employeeRepository.findById(employeeId).orElse(null);
                    if (employee != null) {
                        basicSalaryField.setText(employee.getBasicSalary().toString());
                    }
                }
            }
        });
        
        // Employee
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.weightx = 0.0;
        panel.add(new JLabel("Employee:"), gbc);
        
        gbc.gridx = 1;
        gbc.gridy = 0;
        gbc.weightx = 1.0;
        panel.add(employeeComboBox, gbc);
        
        // Payment Date
        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.weightx = 0.0;
        panel.add(new JLabel("Payment Date (yyyy-MM-dd):"), gbc);
        
        gbc.gridx = 1;
        gbc.gridy = 1;
        gbc.weightx = 1.0;
        panel.add(paymentDateField, gbc);
        
        // Payment Period
        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.weightx = 0.0;
        panel.add(new JLabel("Payment Period:"), gbc);
        
        gbc.gridx = 1;
        gbc.gridy = 2;
        gbc.weightx = 1.0;
        panel.add(paymentPeriodField, gbc);
        
        // Basic Salary
        gbc.gridx = 0;
        gbc.gridy = 3;
        gbc.weightx = 0.0;
        panel.add(new JLabel("Basic Salary:"), gbc);
        
        gbc.gridx = 1;
        gbc.gridy = 3;
        gbc.weightx = 1.0;
        panel.add(basicSalaryField, gbc);
        
        // Overtime Hours
        gbc.gridx = 0;
        gbc.gridy = 4;
        gbc.weightx = 0.0;
        panel.add(new JLabel("Overtime Hours:"), gbc);
        
        gbc.gridx = 1;
        gbc.gridy = 4;
        gbc.weightx = 1.0;
        panel.add(overtimeHoursField, gbc);
        
        // Overtime Rate
        gbc.gridx = 0;
        gbc.gridy = 5;
        gbc.weightx = 0.0;
        panel.add(new JLabel("Overtime Rate:"), gbc);
        
        gbc.gridx = 1;
        gbc.gridy = 5;
        gbc.weightx = 1.0;
        panel.add(overtimeRateField, gbc);
        
        // Allowances
        gbc.gridx = 0;
        gbc.gridy = 6;
        gbc.weightx = 0.0;
        panel.add(new JLabel("Allowances:"), gbc);
        
        gbc.gridx = 1;
        gbc.gridy = 6;
        gbc.weightx = 1.0;
        panel.add(allowancesField, gbc);
        
        // Deductions
        gbc.gridx = 0;
        gbc.gridy = 7;
        gbc.weightx = 0.0;
        panel.add(new JLabel("Deductions:"), gbc);
        
        gbc.gridx = 1;
        gbc.gridy = 7;
        gbc.weightx = 1.0;
        panel.add(deductionsField, gbc);
        
        // Tax Amount
        gbc.gridx = 0;
        gbc.gridy = 8;
        gbc.weightx = 0.0;
        panel.add(new JLabel("Tax Amount:"), gbc);
        
        gbc.gridx = 1;
        gbc.gridy = 8;
        gbc.weightx = 1.0;
        panel.add(taxAmountField, gbc);
        
        // Calculate Button (placed next to tax amount)
        gbc.gridx = 2;
        gbc.gridy = 8;
        gbc.weightx = 0.0;
        calculateButton = new JButton("Calculate");
        calculateButton.addActionListener(e -> calculateNetSalary());
        panel.add(calculateButton, gbc);
        
        // Net Salary
        gbc.gridx = 0;
        gbc.gridy = 9;
        gbc.weightx = 0.0;
        panel.add(new JLabel("Net Salary:"), gbc);
        
        gbc.gridx = 1;
        gbc.gridy = 9;
        gbc.weightx = 1.0;
        panel.add(netSalaryField, gbc);
        
        // Payment Status
        gbc.gridx = 0;
        gbc.gridy = 10;
        gbc.weightx = 0.0;
        panel.add(new JLabel("Payment Status:"), gbc);
        
        gbc.gridx = 1;
        gbc.gridy = 10;
        gbc.weightx = 1.0;
        panel.add(paymentStatusComboBox, gbc);
        
        // Payment Method
        gbc.gridx = 0;
        gbc.gridy = 11;
        gbc.weightx = 0.0;
        panel.add(new JLabel("Payment Method:"), gbc);
        
        gbc.gridx = 1;
        gbc.gridy = 11;
        gbc.weightx = 1.0;
        panel.add(paymentMethodField, gbc);
        
        // Remarks
        gbc.gridx = 0;
        gbc.gridy = 12;
        gbc.weightx = 0.0;
        panel.add(new JLabel("Remarks:"), gbc);
        
        gbc.gridx = 1;
        gbc.gridy = 12;
        gbc.weightx = 1.0;
        gbc.gridwidth = 2;
        JScrollPane remarksScrollPane = new JScrollPane(remarksArea);
        panel.add(remarksScrollPane, gbc);
        
        return panel;
    }
    
    private JPanel createButtonPanel() {
        JPanel panel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        
        saveButton = new JButton(salaryToEdit == null ? "Add Salary Record" : "Update Salary Record");
        cancelButton = new JButton("Cancel");
        
        saveButton.addActionListener(e -> saveSalary());
        cancelButton.addActionListener(e -> parentDialog.dispose());
        
        panel.add(saveButton);
        panel.add(cancelButton);
        
        return panel;
    }
    
    private void loadSalaryData() {
        if (salaryToEdit != null) {
            // Set employee
            String employeeName = salaryToEdit.getEmployee().getFirstName() + " " + salaryToEdit.getEmployee().getLastName();
            employeeComboBox.setSelectedItem(employeeName);
            
            // Set payment date
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
            paymentDateField.setText(salaryToEdit.getPaymentDate().format(formatter));
            
            // Set other fields
            paymentPeriodField.setText(salaryToEdit.getPaymentPeriod());
            basicSalaryField.setText(salaryToEdit.getBasicSalary().toString());
            overtimeHoursField.setText(salaryToEdit.getOvertimeHours().toString());
            overtimeRateField.setText(salaryToEdit.getOvertimeRate().toString());
            allowancesField.setText(salaryToEdit.getAllowances().toString());
            deductionsField.setText(salaryToEdit.getDeductions().toString());
            taxAmountField.setText(salaryToEdit.getTaxAmount().toString());
            netSalaryField.setText(salaryToEdit.getNetSalary().toString());
            paymentStatusComboBox.setSelectedItem(salaryToEdit.getPaymentStatus());
            paymentMethodField.setText(salaryToEdit.getPaymentMethod());
            
            if (salaryToEdit.getRemarks() != null) {
                remarksArea.setText(salaryToEdit.getRemarks());
            }
        }
    }
    
    private void calculateNetSalary() {
        try {
            // Get input values
            BigDecimal basicSalary = new BigDecimal(basicSalaryField.getText().trim());
            int overtimeHours = Integer.parseInt(overtimeHoursField.getText().trim());
            BigDecimal overtimeRate = new BigDecimal(overtimeRateField.getText().trim());
            BigDecimal allowances = new BigDecimal(allowancesField.getText().trim());
            BigDecimal deductions = new BigDecimal(deductionsField.getText().trim());
            BigDecimal taxAmount = new BigDecimal(taxAmountField.getText().trim());
            
            // Calculate overtime pay
            BigDecimal overtimePay = overtimeRate.multiply(BigDecimal.valueOf(overtimeHours));
            
            // Calculate gross salary
            BigDecimal grossSalary = basicSalary.add(overtimePay).add(allowances);
            
            // Calculate net salary
            BigDecimal netSalary = grossSalary.subtract(deductions).subtract(taxAmount);
            
            // Set net salary field
            netSalaryField.setText(netSalary.toString());
            
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(
                    this,
                    "Please enter valid numbers for all numeric fields.",
                    "Calculation Error",
                    JOptionPane.ERROR_MESSAGE
            );
        }
    }
    
    private boolean validateForm() {
        StringBuilder errors = new StringBuilder();
        
        if (employeeComboBox.getSelectedItem() == null || employeeComboBox.getSelectedItem().toString().isEmpty()) {
            errors.append("Employee is required\n");
        }
        
        // Validate payment date format
        try {
            LocalDate.parse(paymentDateField.getText().trim());
        } catch (DateTimeParseException e) {
            errors.append("Payment date must be in format yyyy-MM-dd\n");
        }
        
        if (paymentPeriodField.getText().trim().isEmpty()) {
            errors.append("Payment period is required\n");
        }
        
        // Validate numeric fields
        try {
            new BigDecimal(basicSalaryField.getText().trim());
        } catch (NumberFormatException e) {
            errors.append("Basic salary must be a valid number\n");
        }
        
        try {
            Integer.parseInt(overtimeHoursField.getText().trim());
        } catch (NumberFormatException e) {
            errors.append("Overtime hours must be a valid integer\n");
        }
        
        try {
            new BigDecimal(overtimeRateField.getText().trim());
        } catch (NumberFormatException e) {
            errors.append("Overtime rate must be a valid number\n");
        }
        
        try {
            new BigDecimal(allowancesField.getText().trim());
        } catch (NumberFormatException e) {
            errors.append("Allowances must be a valid number\n");
        }
        
        try {
            new BigDecimal(deductionsField.getText().trim());
        } catch (NumberFormatException e) {
            errors.append("Deductions must be a valid number\n");
        }
        
        try {
            new BigDecimal(taxAmountField.getText().trim());
        } catch (NumberFormatException e) {
            errors.append("Tax amount must be a valid number\n");
        }
        
        try {
            new BigDecimal(netSalaryField.getText().trim());
        } catch (NumberFormatException e) {
            errors.append("Net salary must be a valid number\n");
        }
        
        if (errors.length() > 0) {
            JOptionPane.showMessageDialog(
                    this,
                    errors.toString(),
                    "Validation Error",
                    JOptionPane.ERROR_MESSAGE
            );
            return false;
        }
        
        return true;
    }
    
    private void saveSalary() {
        if (!validateForm()) {
            return;
        }
        
        // Create new salary or update existing one
        Salary salary = (salaryToEdit != null) ? salaryToEdit : new Salary();
        
        // Get selected employee
        String selectedEmployeeName = (String) employeeComboBox.getSelectedItem();
        Long employeeId = employeeNameToIdMap.get(selectedEmployeeName);
        Employee employee = employeeRepository.findById(employeeId)
                .orElseThrow(() -> new IllegalArgumentException("Selected employee not found"));
        
        // Set salary properties
        salary.setEmployee(employee);
        salary.setPaymentDate(LocalDate.parse(paymentDateField.getText().trim()));
        salary.setPaymentPeriod(paymentPeriodField.getText().trim());
        salary.setBasicSalary(new BigDecimal(basicSalaryField.getText().trim()));
        salary.setOvertimeHours(Integer.parseInt(overtimeHoursField.getText().trim()));
        salary.setOvertimeRate(new BigDecimal(overtimeRateField.getText().trim()));
        salary.setAllowances(new BigDecimal(allowancesField.getText().trim()));
        salary.setDeductions(new BigDecimal(deductionsField.getText().trim()));
        salary.setTaxAmount(new BigDecimal(taxAmountField.getText().trim()));
        salary.setNetSalary(new BigDecimal(netSalaryField.getText().trim()));
        salary.setPaymentStatus((String) paymentStatusComboBox.getSelectedItem());
        salary.setPaymentMethod(paymentMethodField.getText().trim());
        salary.setRemarks(remarksArea.getText().trim());
        
        // Save salary to repository
        salaryRepository.save(salary);
        
        // Close dialog
        parentDialog.dispose();
    }
} 