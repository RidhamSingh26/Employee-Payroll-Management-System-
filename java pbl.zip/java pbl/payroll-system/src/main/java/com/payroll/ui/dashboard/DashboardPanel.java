package com.payroll.ui.dashboard;

import com.payroll.model.Employee;
import com.payroll.model.Salary;
import com.payroll.repository.EmployeeRepository;
import com.payroll.repository.SalaryRepository;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.category.DefaultCategoryDataset;
import org.jfree.data.general.DefaultPieDataset;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.border.TitledBorder;
import java.awt.*;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class DashboardPanel extends JPanel {

    private final EmployeeRepository employeeRepository;
    private final SalaryRepository salaryRepository;
    
    private JPanel statsPanel;
    private JPanel chartsPanel;
    private JPanel recentDataPanel;
    
    private JLabel totalEmployeesLabel;
    private JLabel totalSalariesLabel;
    private JLabel pendingPaymentsLabel;
    private JLabel totalDepartmentsLabel;
    
    public DashboardPanel(EmployeeRepository employeeRepository, SalaryRepository salaryRepository) {
        this.employeeRepository = employeeRepository;
        this.salaryRepository = salaryRepository;
        
        setLayout(new BorderLayout(10, 10));
        setBorder(new EmptyBorder(15, 15, 15, 15));
        
        // Create header panel
        JPanel headerPanel = createHeaderPanel();
        add(headerPanel, BorderLayout.NORTH);
        
        // Create main content panel with GridBagLayout
        JPanel contentPanel = new JPanel(new GridBagLayout());
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.BOTH;
        gbc.insets = new Insets(5, 5, 5, 5);
        
        // Add stats cards panel
        gbc.gridx = 0;
        gbc.gridy = 0;
        gbc.gridwidth = 2;
        gbc.weightx = 1.0;
        gbc.weighty = 0.2;
        statsPanel = createStatsPanel();
        contentPanel.add(statsPanel, gbc);
        
        // Add charts panel
        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.gridwidth = 2;
        gbc.weightx = 1.0;
        gbc.weighty = 0.4;
        chartsPanel = createChartsPanel();
        contentPanel.add(chartsPanel, gbc);
        
        // Add recent data panel
        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.gridwidth = 2;
        gbc.weightx = 1.0;
        gbc.weighty = 0.4;
        recentDataPanel = createRecentDataPanel();
        contentPanel.add(recentDataPanel, gbc);
        
        // Add scroll pane for content
        JScrollPane scrollPane = new JScrollPane(contentPanel);
        scrollPane.setBorder(null);
        scrollPane.getVerticalScrollBar().setUnitIncrement(16);
        add(scrollPane, BorderLayout.CENTER);
        
        // Initialize data
        refreshData();
    }
    
    private JPanel createHeaderPanel() {
        JPanel panel = new JPanel(new BorderLayout());
        panel.setBackground(Color.WHITE);
        panel.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createMatteBorder(0, 0, 1, 0, Color.LIGHT_GRAY),
                BorderFactory.createEmptyBorder(10, 10, 10, 10)
        ));
        
        JLabel titleLabel = new JLabel("Dashboard");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 24));
        titleLabel.setForeground(new Color(78, 115, 223));
        
        JLabel subtitleLabel = new JLabel("Welcome to PayrollPro, your comprehensive payroll management system");
        subtitleLabel.setFont(new Font("Arial", Font.PLAIN, 14));
        subtitleLabel.setForeground(Color.GRAY);
        
        JPanel labelPanel = new JPanel(new GridLayout(2, 1));
        labelPanel.setBackground(Color.WHITE);
        labelPanel.add(titleLabel);
        labelPanel.add(subtitleLabel);
        
        panel.add(labelPanel, BorderLayout.WEST);
        
        return panel;
    }
    
    private JPanel createStatsPanel() {
        JPanel panel = new JPanel(new GridLayout(1, 4, 15, 0));
        panel.setBackground(Color.WHITE);
        
        // Total Employees Card
        JPanel employeesCard = createStatCard("Total Employees", "0", new Color(78, 115, 223));
        totalEmployeesLabel = (JLabel) ((JPanel)((JPanel) employeesCard.getComponent(0)).getComponent(0)).getComponent(1);
        panel.add(employeesCard);
        
        // Total Salaries Card
        JPanel salariesCard = createStatCard("Salary Records", "0", new Color(28, 200, 138));
        totalSalariesLabel = (JLabel) ((JPanel)((JPanel) salariesCard.getComponent(0)).getComponent(0)).getComponent(1);
        panel.add(salariesCard);
        
        // Departments Card
        JPanel departmentsCard = createStatCard("Departments", "0", new Color(246, 194, 62));
        totalDepartmentsLabel = (JLabel) ((JPanel)((JPanel) departmentsCard.getComponent(0)).getComponent(0)).getComponent(1);
        panel.add(departmentsCard);
        
        // Pending Payments Card
        JPanel pendingCard = createStatCard("Pending Payments", "0", new Color(231, 74, 59));
        pendingPaymentsLabel = (JLabel) ((JPanel)((JPanel) pendingCard.getComponent(0)).getComponent(0)).getComponent(1);
        panel.add(pendingCard);
        
        return panel;
    }
    
    private JPanel createStatCard(String title, String value, Color color) {
        JPanel card = new JPanel(new BorderLayout());
        card.setBackground(Color.WHITE);
        card.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(222, 226, 230), 1),
                BorderFactory.createEmptyBorder(15, 15, 15, 15)
        ));
        
        // Create content panel
        JPanel contentPanel = new JPanel(new BorderLayout(0, 10));
        contentPanel.setBackground(Color.WHITE);
        
        // Create title and value panel
        JPanel dataPanel = new JPanel(new GridLayout(2, 1));
        dataPanel.setBackground(Color.WHITE);
        
        JLabel titleLabel = new JLabel(title);
        titleLabel.setFont(new Font("Arial", Font.BOLD, 14));
        titleLabel.setForeground(Color.GRAY);
        
        JLabel valueLabel = new JLabel(value);
        valueLabel.setFont(new Font("Arial", Font.BOLD, 24));
        valueLabel.setForeground(color);
        
        dataPanel.add(titleLabel);
        dataPanel.add(valueLabel);
        
        // Create icon panel
        JPanel iconPanel = new JPanel(new BorderLayout());
        iconPanel.setBackground(Color.WHITE);
        iconPanel.setPreferredSize(new Dimension(40, 40));
        
        JLabel iconLabel = new JLabel();
        iconLabel.setHorizontalAlignment(JLabel.CENTER);
        iconPanel.add(iconLabel, BorderLayout.CENTER);
        
        // Add components to content panel
        contentPanel.add(dataPanel, BorderLayout.CENTER);
        contentPanel.add(iconPanel, BorderLayout.EAST);
        
        // Add content panel to card
        card.add(contentPanel, BorderLayout.CENTER);
        
        return card;
    }
    
    private JPanel createChartsPanel() {
        JPanel panel = new JPanel(new GridLayout(1, 2, 15, 0));
        panel.setBackground(Color.WHITE);
        
        // Department Distribution Chart
        JPanel departmentChartPanel = new JPanel(new BorderLayout());
        departmentChartPanel.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(222, 226, 230), 1),
                BorderFactory.createEmptyBorder(15, 15, 15, 15)
        ));
        departmentChartPanel.setBackground(Color.WHITE);
        
        JLabel departmentChartTitle = new JLabel("Department Distribution");
        departmentChartTitle.setFont(new Font("Arial", Font.BOLD, 16));
        departmentChartPanel.add(departmentChartTitle, BorderLayout.NORTH);
        
        // Placeholder for the chart - will be populated in refreshData
        departmentChartPanel.add(new JPanel(), BorderLayout.CENTER);
        
        // Salary Distribution Chart
        JPanel salaryChartPanel = new JPanel(new BorderLayout());
        salaryChartPanel.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(222, 226, 230), 1),
                BorderFactory.createEmptyBorder(15, 15, 15, 15)
        ));
        salaryChartPanel.setBackground(Color.WHITE);
        
        JLabel salaryChartTitle = new JLabel("Salary Distribution");
        salaryChartTitle.setFont(new Font("Arial", Font.BOLD, 16));
        salaryChartPanel.add(salaryChartTitle, BorderLayout.NORTH);
        
        // Placeholder for the chart - will be populated in refreshData
        salaryChartPanel.add(new JPanel(), BorderLayout.CENTER);
        
        panel.add(departmentChartPanel);
        panel.add(salaryChartPanel);
        
        return panel;
    }
    
    private JPanel createRecentDataPanel() {
        JPanel panel = new JPanel(new GridLayout(1, 2, 15, 0));
        panel.setBackground(Color.WHITE);
        
        // Recent Employees Panel
        JPanel recentEmployeesPanel = new JPanel(new BorderLayout());
        recentEmployeesPanel.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(222, 226, 230), 1),
                BorderFactory.createEmptyBorder(15, 15, 15, 15)
        ));
        recentEmployeesPanel.setBackground(Color.WHITE);
        
        JPanel employeesHeaderPanel = new JPanel(new BorderLayout());
        employeesHeaderPanel.setBackground(Color.WHITE);
        employeesHeaderPanel.setBorder(BorderFactory.createEmptyBorder(0, 0, 10, 0));
        
        JLabel employeesTitle = new JLabel("Recent Employees");
        employeesTitle.setFont(new Font("Arial", Font.BOLD, 16));
        employeesHeaderPanel.add(employeesTitle, BorderLayout.WEST);
        
        JButton viewAllEmployeesBtn = new JButton("View All");
        viewAllEmployeesBtn.setFont(new Font("Arial", Font.PLAIN, 12));
        employeesHeaderPanel.add(viewAllEmployeesBtn, BorderLayout.EAST);
        
        recentEmployeesPanel.add(employeesHeaderPanel, BorderLayout.NORTH);
        
        // Placeholder for the employee list - will be populated in refreshData
        recentEmployeesPanel.add(new JPanel(), BorderLayout.CENTER);
        
        // Recent Salaries Panel
        JPanel recentSalariesPanel = new JPanel(new BorderLayout());
        recentSalariesPanel.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(222, 226, 230), 1),
                BorderFactory.createEmptyBorder(15, 15, 15, 15)
        ));
        recentSalariesPanel.setBackground(Color.WHITE);
        
        JPanel salariesHeaderPanel = new JPanel(new BorderLayout());
        salariesHeaderPanel.setBackground(Color.WHITE);
        salariesHeaderPanel.setBorder(BorderFactory.createEmptyBorder(0, 0, 10, 0));
        
        JLabel salariesTitle = new JLabel("Recent Salary Records");
        salariesTitle.setFont(new Font("Arial", Font.BOLD, 16));
        salariesHeaderPanel.add(salariesTitle, BorderLayout.WEST);
        
        JButton viewAllSalariesBtn = new JButton("View All");
        viewAllSalariesBtn.setFont(new Font("Arial", Font.PLAIN, 12));
        salariesHeaderPanel.add(viewAllSalariesBtn, BorderLayout.EAST);
        
        recentSalariesPanel.add(salariesHeaderPanel, BorderLayout.NORTH);
        
        // Placeholder for the salary list - will be populated in refreshData
        recentSalariesPanel.add(new JPanel(), BorderLayout.CENTER);
        
        panel.add(recentEmployeesPanel);
        panel.add(recentSalariesPanel);
        
        return panel;
    }
    
    private JTable createEmployeeTable(List<Employee> employees) {
        String[] columnNames = {"Name", "Position", "Department"};
        Object[][] data = new Object[employees.size()][3];
        
        for (int i = 0; i < employees.size(); i++) {
            Employee employee = employees.get(i);
            data[i][0] = employee.getFirstName() + " " + employee.getLastName();
            data[i][1] = employee.getPosition();
            data[i][2] = employee.getDepartment();
        }
        
        JTable table = new JTable(data, columnNames);
        table.setRowHeight(30);
        table.setShowGrid(false);
        table.setIntercellSpacing(new Dimension(0, 0));
        table.getTableHeader().setFont(new Font("Arial", Font.BOLD, 12));
        
        return table;
    }
    
    private JTable createSalaryTable(List<Salary> salaries) {
        String[] columnNames = {"Employee", "Amount", "Date", "Status"};
        Object[][] data = new Object[salaries.size()][4];
        
        for (int i = 0; i < salaries.size(); i++) {
            Salary salary = salaries.get(i);
            data[i][0] = salary.getEmployee().getFirstName() + " " + salary.getEmployee().getLastName();
            data[i][1] = "$" + salary.getNetSalary();
            data[i][2] = salary.getPaymentDate().toString();
            data[i][3] = salary.getPaymentStatus();
        }
        
        JTable table = new JTable(data, columnNames);
        table.setRowHeight(30);
        table.setShowGrid(false);
        table.setIntercellSpacing(new Dimension(0, 0));
        table.getTableHeader().setFont(new Font("Arial", Font.BOLD, 12));
        
        return table;
    }
    
    private void createDepartmentChart() {
        JPanel departmentChartPanel = (JPanel) chartsPanel.getComponent(0);
        departmentChartPanel.remove(1); // Remove placeholder panel
        
        List<Employee> employees = employeeRepository.findAll();
        Map<String, Long> departmentCounts = employees.stream()
                .collect(Collectors.groupingBy(Employee::getDepartment, Collectors.counting()));
        
        DefaultCategoryDataset dataset = new DefaultCategoryDataset();
        for (Map.Entry<String, Long> entry : departmentCounts.entrySet()) {
            dataset.addValue(entry.getValue(), "Employees", entry.getKey());
        }
        
        JFreeChart chart = ChartFactory.createBarChart(
                null,
                "Department",
                "Employees",
                dataset,
                PlotOrientation.VERTICAL,
                false,
                true,
                false
        );
        
        ChartPanel chartPanel = new ChartPanel(chart);
        chartPanel.setPreferredSize(new Dimension(400, 300));
        departmentChartPanel.add(chartPanel, BorderLayout.CENTER);
    }
    
    private void createSalaryChart() {
        JPanel salaryChartPanel = (JPanel) chartsPanel.getComponent(1);
        salaryChartPanel.remove(1); // Remove placeholder panel
        
        List<Salary> salaries = salaryRepository.findAll();
        Map<String, Double> departmentSalaries = new HashMap<>();
        
        // Calculate total salary for each department
        for (Salary salary : salaries) {
            String department = salary.getEmployee().getDepartment();
            double amount = salary.getNetSalary().doubleValue();
            
            departmentSalaries.put(
                    department,
                    departmentSalaries.getOrDefault(department, 0.0) + amount
            );
        }
        
        DefaultPieDataset dataset = new DefaultPieDataset();
        for (Map.Entry<String, Double> entry : departmentSalaries.entrySet()) {
            dataset.setValue(entry.getKey(), entry.getValue());
        }
        
        JFreeChart chart = ChartFactory.createPieChart(
                null,
                dataset,
                true,
                true,
                false
        );
        
        ChartPanel chartPanel = new ChartPanel(chart);
        chartPanel.setPreferredSize(new Dimension(400, 300));
        salaryChartPanel.add(chartPanel, BorderLayout.CENTER);
    }
    
    public void refreshData() {
        List<Employee> employees = employeeRepository.findAll();
        List<Salary> salaries = salaryRepository.findAll();
        
        // Update stats labels
        totalEmployeesLabel.setText(String.valueOf(employees.size()));
        totalSalariesLabel.setText(String.valueOf(salaries.size()));
        
        // Count departments
        long departmentCount = employees.stream()
                .map(Employee::getDepartment)
                .distinct()
                .count();
        totalDepartmentsLabel.setText(String.valueOf(departmentCount));
        
        // Count pending payments
        long pendingPayments = salaries.stream()
                .filter(s -> "PENDING".equals(s.getPaymentStatus()))
                .count();
        pendingPaymentsLabel.setText(String.valueOf(pendingPayments));
        
        // Create department distribution chart
        createDepartmentChart();
        
        // Create salary distribution chart
        createSalaryChart();
        
        // Update recent employees table
        JPanel recentEmployeesPanel = (JPanel) recentDataPanel.getComponent(0);
        if (recentEmployeesPanel.getComponentCount() > 1) {
            recentEmployeesPanel.remove(1);
        }
        
        List<Employee> recentEmployees = employees.stream()
                .limit(5)
                .collect(Collectors.toList());
        
        JTable employeeTable = createEmployeeTable(recentEmployees);
        JScrollPane employeeScrollPane = new JScrollPane(employeeTable);
        employeeScrollPane.setBorder(null);
        recentEmployeesPanel.add(employeeScrollPane, BorderLayout.CENTER);
        
        // Update recent salaries table
        JPanel recentSalariesPanel = (JPanel) recentDataPanel.getComponent(1);
        if (recentSalariesPanel.getComponentCount() > 1) {
            recentSalariesPanel.remove(1);
        }
        
        List<Salary> recentSalaries = salaries.stream()
                .limit(5)
                .collect(Collectors.toList());
        
        JTable salaryTable = createSalaryTable(recentSalaries);
        JScrollPane salaryScrollPane = new JScrollPane(salaryTable);
        salaryScrollPane.setBorder(null);
        recentSalariesPanel.add(salaryScrollPane, BorderLayout.CENTER);
        
        // Repaint and revalidate
        revalidate();
        repaint();
    }
} 