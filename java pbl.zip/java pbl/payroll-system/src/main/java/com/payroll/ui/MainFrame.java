package com.payroll.ui;

import com.payroll.model.Employee;
import com.payroll.model.Salary;
import com.payroll.repository.EmployeeRepository;
import com.payroll.repository.SalaryRepository;
import com.payroll.ui.employee.EmployeeListPanel;
import com.payroll.ui.employee.EmployeeFormPanel;
import com.payroll.ui.dashboard.DashboardPanel;
import com.payroll.ui.salary.SalaryListPanel;
import com.payroll.ui.salary.SalaryFormPanel;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.swing.*;
import java.awt.*;
import java.util.List;

@Component
public class MainFrame extends JFrame {

    private final EmployeeRepository employeeRepository;
    private final SalaryRepository salaryRepository;
    
    private JTabbedPane tabbedPane;
    private JPanel mainPanel;
    private DashboardPanel dashboardPanel;
    private EmployeeListPanel employeeListPanel;
    private SalaryListPanel salaryListPanel;
    
    @Autowired
    public MainFrame(EmployeeRepository employeeRepository, SalaryRepository salaryRepository) {
        this.employeeRepository = employeeRepository;
        this.salaryRepository = salaryRepository;
        
        initializeUI();
    }
    
    private void initializeUI() {
        // Set up the JFrame
        setTitle("PayrollPro - Employee Payroll System");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1200, 800);
        setLocationRelativeTo(null);
        
        // Create main panel with BorderLayout
        mainPanel = new JPanel(new BorderLayout());
        
        // Create header panel
        JPanel headerPanel = createHeaderPanel();
        mainPanel.add(headerPanel, BorderLayout.NORTH);
        
        // Create tabbed pane for main content
        tabbedPane = new JTabbedPane();
        
        // Create and add dashboard panel
        dashboardPanel = new DashboardPanel(employeeRepository, salaryRepository);
        tabbedPane.addTab("Dashboard", new ImageIcon(), dashboardPanel, "View dashboard");
        
        // Create and add employees panel
        employeeListPanel = new EmployeeListPanel(employeeRepository, this);
        tabbedPane.addTab("Employees", new ImageIcon(), employeeListPanel, "Manage employees");
        
        // Create and add salaries panel
        salaryListPanel = new SalaryListPanel(salaryRepository, employeeRepository, this);
        tabbedPane.addTab("Salaries", new ImageIcon(), salaryListPanel, "Manage salaries");
        
        // Add tabbed pane to main panel
        mainPanel.add(tabbedPane, BorderLayout.CENTER);
        
        // Create status bar
        JPanel statusBar = createStatusBar();
        mainPanel.add(statusBar, BorderLayout.SOUTH);
        
        // Add main panel to frame
        add(mainPanel);
    }
    
    private JPanel createHeaderPanel() {
        JPanel headerPanel = new JPanel();
        headerPanel.setLayout(new BorderLayout());
        headerPanel.setBackground(new Color(78, 115, 223));
        headerPanel.setPreferredSize(new Dimension(getWidth(), 60));
        
        // Add logo and title
        JLabel titleLabel = new JLabel("PayrollPro");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 22));
        titleLabel.setForeground(Color.WHITE);
        titleLabel.setBorder(BorderFactory.createEmptyBorder(0, 20, 0, 0));
        headerPanel.add(titleLabel, BorderLayout.WEST);
        
        return headerPanel;
    }
    
    private JPanel createStatusBar() {
        JPanel statusBar = new JPanel();
        statusBar.setLayout(new BorderLayout());
        statusBar.setPreferredSize(new Dimension(getWidth(), 25));
        statusBar.setBorder(BorderFactory.createEtchedBorder());
        
        // Add status label
        JLabel statusLabel = new JLabel(" Ready");
        statusBar.add(statusLabel, BorderLayout.WEST);
        
        return statusBar;
    }
    
    public void showEmployeeForm(Employee employee) {
        JDialog dialog = new JDialog(this, "Employee Form", true);
        dialog.setSize(600, 500);
        dialog.setLocationRelativeTo(this);
        
        EmployeeFormPanel formPanel = new EmployeeFormPanel(employeeRepository, dialog, employee);
        dialog.add(formPanel);
        dialog.setVisible(true);
        
        // Refresh employee list after dialog is closed
        employeeListPanel.refreshEmployeeList();
        dashboardPanel.refreshData();
    }
    
    public void showSalaryForm(Salary salary) {
        JDialog dialog = new JDialog(this, "Salary Form", true);
        dialog.setSize(600, 600);
        dialog.setLocationRelativeTo(this);
        
        SalaryFormPanel formPanel = new SalaryFormPanel(salaryRepository, employeeRepository, dialog, salary);
        dialog.add(formPanel);
        dialog.setVisible(true);
        
        // Refresh salary list after dialog is closed
        salaryListPanel.refreshSalaryList();
        dashboardPanel.refreshData();
    }
    
    public void refreshAllData() {
        dashboardPanel.refreshData();
        employeeListPanel.refreshEmployeeList();
        salaryListPanel.refreshSalaryList();
    }
} 