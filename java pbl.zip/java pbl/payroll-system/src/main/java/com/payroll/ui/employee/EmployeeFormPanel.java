package com.payroll.ui.employee;

import com.payroll.model.Employee;
import com.payroll.repository.EmployeeRepository;

import javax.swing.*;
import java.awt.*;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;

public class EmployeeFormPanel extends JPanel {

    private final EmployeeRepository employeeRepository;
    private final JDialog parentDialog;
    private final Employee employeeToEdit;
    
    private JTextField firstNameField;
    private JTextField lastNameField;
    private JTextField emailField;
    private JTextField phoneField;
    private JTextField hireDateField;
    private JTextField positionField;
    private JComboBox<String> departmentComboBox;
    private JTextField basicSalaryField;
    private JTextField taxPercentageField;
    private JTextField allowancesField;
    private JTextField deductionsField;
    
    private JButton saveButton;
    private JButton cancelButton;
    
    public EmployeeFormPanel(EmployeeRepository employeeRepository, JDialog parentDialog, Employee employeeToEdit) {
        this.employeeRepository = employeeRepository;
        this.parentDialog = parentDialog;
        this.employeeToEdit = employeeToEdit;
        
        setLayout(new BorderLayout(10, 10));
        setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));
        
        // Create form panel
        JPanel formPanel = createFormPanel();
        add(formPanel, BorderLayout.CENTER);
        
        // Create button panel
        JPanel buttonPanel = createButtonPanel();
        add(buttonPanel, BorderLayout.SOUTH);
        
        // Load employee data if editing
        if (employeeToEdit != null) {
            loadEmployeeData();
        }
    }
    
    private JPanel createFormPanel() {
        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBorder(BorderFactory.createEmptyBorder(0, 0, 10, 0));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.fill = GridBagConstraints.HORIZONTAL;
        gbc.insets = new Insets(5, 5, 5, 5);
        
        // Create form fields
        firstNameField = new JTextField(20);
        lastNameField = new JTextField(20);
        emailField = new JTextField(20);
        phoneField = new JTextField(20);
        hireDateField = new JTextField(20);
        positionField = new JTextField(20);
        
        String[] departments = {"IT", "HR", "Finance", "Marketing", "Sales", "Operations"};
        departmentComboBox = new JComboBox<>(departments);
        
        basicSalaryField = new JTextField(20);
        taxPercentageField = new JTextField(20);
        allowancesField = new JTextField(20);
        deductionsField = new JTextField(20);
        
        // First Name
        gbc.gridx = 0;
        gbc.gridy = 0;
        panel.add(new JLabel("First Name:"), gbc);
        
        gbc.gridx = 1;
        gbc.gridy = 0;
        gbc.weightx = 1.0;
        panel.add(firstNameField, gbc);
        
        // Last Name
        gbc.gridx = 0;
        gbc.gridy = 1;
        gbc.weightx = 0.0;
        panel.add(new JLabel("Last Name:"), gbc);
        
        gbc.gridx = 1;
        gbc.gridy = 1;
        gbc.weightx = 1.0;
        panel.add(lastNameField, gbc);
        
        // Email
        gbc.gridx = 0;
        gbc.gridy = 2;
        gbc.weightx = 0.0;
        panel.add(new JLabel("Email:"), gbc);
        
        gbc.gridx = 1;
        gbc.gridy = 2;
        gbc.weightx = 1.0;
        panel.add(emailField, gbc);
        
        // Phone
        gbc.gridx = 0;
        gbc.gridy = 3;
        gbc.weightx = 0.0;
        panel.add(new JLabel("Phone:"), gbc);
        
        gbc.gridx = 1;
        gbc.gridy = 3;
        gbc.weightx = 1.0;
        panel.add(phoneField, gbc);
        
        // Hire Date
        gbc.gridx = 0;
        gbc.gridy = 4;
        gbc.weightx = 0.0;
        panel.add(new JLabel("Hire Date (yyyy-MM-dd):"), gbc);
        
        gbc.gridx = 1;
        gbc.gridy = 4;
        gbc.weightx = 1.0;
        panel.add(hireDateField, gbc);
        
        // Position
        gbc.gridx = 0;
        gbc.gridy = 5;
        gbc.weightx = 0.0;
        panel.add(new JLabel("Position:"), gbc);
        
        gbc.gridx = 1;
        gbc.gridy = 5;
        gbc.weightx = 1.0;
        panel.add(positionField, gbc);
        
        // Department
        gbc.gridx = 0;
        gbc.gridy = 6;
        gbc.weightx = 0.0;
        panel.add(new JLabel("Department:"), gbc);
        
        gbc.gridx = 1;
        gbc.gridy = 6;
        gbc.weightx = 1.0;
        panel.add(departmentComboBox, gbc);
        
        // Basic Salary
        gbc.gridx = 0;
        gbc.gridy = 7;
        gbc.weightx = 0.0;
        panel.add(new JLabel("Basic Salary:"), gbc);
        
        gbc.gridx = 1;
        gbc.gridy = 7;
        gbc.weightx = 1.0;
        panel.add(basicSalaryField, gbc);
        
        // Tax Percentage
        gbc.gridx = 0;
        gbc.gridy = 8;
        gbc.weightx = 0.0;
        panel.add(new JLabel("Tax Percentage:"), gbc);
        
        gbc.gridx = 1;
        gbc.gridy = 8;
        gbc.weightx = 1.0;
        panel.add(taxPercentageField, gbc);
        
        // Allowances
        gbc.gridx = 0;
        gbc.gridy = 9;
        gbc.weightx = 0.0;
        panel.add(new JLabel("Allowances:"), gbc);
        
        gbc.gridx = 1;
        gbc.gridy = 9;
        gbc.weightx = 1.0;
        panel.add(allowancesField, gbc);
        
        // Deductions
        gbc.gridx = 0;
        gbc.gridy = 10;
        gbc.weightx = 0.0;
        panel.add(new JLabel("Deductions:"), gbc);
        
        gbc.gridx = 1;
        gbc.gridy = 10;
        gbc.weightx = 1.0;
        panel.add(deductionsField, gbc);
        
        return panel;
    }
    
    private JPanel createButtonPanel() {
        JPanel panel = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        
        saveButton = new JButton(employeeToEdit == null ? "Add Employee" : "Update Employee");
        cancelButton = new JButton("Cancel");
        
        saveButton.addActionListener(e -> saveEmployee());
        cancelButton.addActionListener(e -> parentDialog.dispose());
        
        panel.add(saveButton);
        panel.add(cancelButton);
        
        return panel;
    }
    
    private void loadEmployeeData() {
        if (employeeToEdit != null) {
            firstNameField.setText(employeeToEdit.getFirstName());
            lastNameField.setText(employeeToEdit.getLastName());
            emailField.setText(employeeToEdit.getEmail());
            phoneField.setText(employeeToEdit.getPhone());
            
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
            hireDateField.setText(employeeToEdit.getHireDate().format(formatter));
            
            positionField.setText(employeeToEdit.getPosition());
            departmentComboBox.setSelectedItem(employeeToEdit.getDepartment());
            
            basicSalaryField.setText(employeeToEdit.getBasicSalary().toString());
            taxPercentageField.setText(employeeToEdit.getTaxPercentage().toString());
            allowancesField.setText(employeeToEdit.getAllowances().toString());
            deductionsField.setText(employeeToEdit.getDeductions().toString());
        } else {
            // Set default values for new employee
            LocalDate now = LocalDate.now();
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
            hireDateField.setText(now.format(formatter));
            
            taxPercentageField.setText("15.0");
            allowancesField.setText("0.0");
            deductionsField.setText("0.0");
        }
    }
    
    private boolean validateForm() {
        StringBuilder errors = new StringBuilder();
        
        if (firstNameField.getText().trim().isEmpty()) {
            errors.append("First name is required\n");
        }
        
        if (lastNameField.getText().trim().isEmpty()) {
            errors.append("Last name is required\n");
        }
        
        if (emailField.getText().trim().isEmpty()) {
            errors.append("Email is required\n");
        }
        
        if (phoneField.getText().trim().isEmpty()) {
            errors.append("Phone is required\n");
        }
        
        // Validate hire date format
        try {
            LocalDate.parse(hireDateField.getText().trim());
        } catch (DateTimeParseException e) {
            errors.append("Hire date must be in format yyyy-MM-dd\n");
        }
        
        if (positionField.getText().trim().isEmpty()) {
            errors.append("Position is required\n");
        }
        
        // Validate numeric fields
        try {
            new BigDecimal(basicSalaryField.getText().trim());
        } catch (NumberFormatException e) {
            errors.append("Basic salary must be a valid number\n");
        }
        
        try {
            new BigDecimal(taxPercentageField.getText().trim());
        } catch (NumberFormatException e) {
            errors.append("Tax percentage must be a valid number\n");
        }
        
        try {
            new BigDecimal(allowancesField.getText().trim());
        } catch (NumberFormatException e) {
            errors.append("Allowances must be a valid number\n");
        }
        
        try {
            new BigDecimal(deductionsField.getText().trim());
        } catch (NumberFormatException e) {
            errors.append("Deductions must be a valid number\n");
        }
        
        if (errors.length() > 0) {
            JOptionPane.showMessageDialog(
                    this,
                    errors.toString(),
                    "Validation Error",
                    JOptionPane.ERROR_MESSAGE
            );
            return false;
        }
        
        return true;
    }
    
    private void saveEmployee() {
        if (!validateForm()) {
            return;
        }
        
        // Create new employee or update existing one
        Employee employee = (employeeToEdit != null) ? employeeToEdit : new Employee();
        
        // Set employee properties
        employee.setFirstName(firstNameField.getText().trim());
        employee.setLastName(lastNameField.getText().trim());
        employee.setEmail(emailField.getText().trim());
        employee.setPhone(phoneField.getText().trim());
        employee.setHireDate(LocalDate.parse(hireDateField.getText().trim()));
        employee.setPosition(positionField.getText().trim());
        employee.setDepartment((String) departmentComboBox.getSelectedItem());
        employee.setBasicSalary(new BigDecimal(basicSalaryField.getText().trim()));
        employee.setTaxPercentage(new BigDecimal(taxPercentageField.getText().trim()));
        employee.setAllowances(new BigDecimal(allowancesField.getText().trim()));
        employee.setDeductions(new BigDecimal(deductionsField.getText().trim()));
        
        // Save employee to repository
        employeeRepository.save(employee);
        
        // Close dialog
        parentDialog.dispose();
    }
} 